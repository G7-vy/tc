package exp4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class weakrobust {

	@Test
	public void test1() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,1912),"17/6/1912");
	}
	@Test
	public void test2() {
		Next d = new Next();
		assertEquals(d.nextday(16,-1,1912),"Invalid Values");
	}
	
	@Test
	public void test3() {
		Next d = new Next();
		assertEquals(d.nextday(16,13,1912),"Invalid Values");
	}
	@Test
	public void test4() {
		Next d = new Next();
		assertEquals(d.nextday(-1,6,1912),"Invalid Values");
	}
	
	@Test
	public void test5() {
		Next d = new Next();
		assertEquals(d.nextday(32,6,1912),"Invalid Values");
	}
	
	@Test
	public void test6() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,1811),"Invalid Values");
	}
	
	@Test
	public void test7() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,2013),"Invalid Values");
	}
	

}
