package exp4;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import exp4.Next;

class strongweaknormal {
	@Test
	public void test1() {
		Next d = new Next();
		assertEquals(d.nextday(16,6,1912),"17/6/1912");
	}
	

}
