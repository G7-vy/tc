package exp3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class worstrobustbva {
	@Test
	public void test01() {
		Next d = new Next();
		assertEquals(d.nextday(1,1,1811),"Invalid Values");
		
	}
	@Test
	public void test1() {
		Next d = new Next();
		assertEquals(d.nextday(1,1,1812),"2/1/1812");
		
	}
	@Test
	public void test2() {
		Next d = new Next();
		assertEquals(d.nextday(1,1,1813),"2/1/1813");
	}
	@Test
	public void test3() {
		Next d = new Next();
		assertEquals(d.nextday(1,1,1912),"2/1/1912");
	}
	@Test
	public void test4() {
		Next d = new Next();
		assertEquals(d.nextday(1,1,2011),"2/1/2011");
	}
	@Test
	public void test5() {
		Next d = new Next();
		assertEquals(d.nextday(1,1,2012),"2/1/2012");
	}
	@Test
	public void test05() {
		Next d = new Next();
		assertEquals(d.nextday(1,1,2013),"Invalid Values");
		
	}
	@Test
	public void test06() {
		Next d = new Next();
		assertEquals(d.nextday(1,2,1811),"Invalid Values");
		
	}
	@Test
	public void test6() {
		Next d = new Next();
		assertEquals(d.nextday(1,2,1812),"2/2/1812");
		
	}
	@Test
	public void test7() {
		Next d = new Next();
		assertEquals(d.nextday(1,2,1813),"2/2/1813");
	}
	@Test
	public void test8() {
		Next d = new Next();
		assertEquals(d.nextday(1,2,1912),"2/2/1912");
	}
	@Test
	public void test9() {
		Next d = new Next();
		assertEquals(d.nextday(1,2,2011),"2/2/2011");
	}
	@Test
	public void test10() {
		Next d = new Next();
		assertEquals(d.nextday(1,2,2012),"2/2/2012");
	}
	@Test
	public void test010() {
		Next d = new Next();
		assertEquals(d.nextday(1,2,2013),"Invalid Values");
		
	}
	@Test
	public void test011() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,1811),"Invalid Values");
		
	}
	@Test
	public void test11() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,1812),"2/6/1812");
		
	}
	@Test
	public void test12() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,1813),"2/6/1813");
	}
	@Test
	public void test13() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,1912),"2/6/1912");
	}
	@Test
	public void test14() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,2011),"2/6/2011");
	}
	@Test
	public void test15() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,2012),"2/6/2012");
	}
	@Test
	public void test015() {
		Next d = new Next();
		assertEquals(d.nextday(1,6,2013),"Invalid Values");
		
	}
	@Test
	public void test016() {
		Next d = new Next();
		assertEquals(d.nextday(1,11,1811),"Invalid Values");
		
	}
	@Test
	public void test16() {
		Next d = new Next();
		assertEquals(d.nextday(1,11,1812),"2/11/1812");
		
	}
	@Test
	public void test17() {
		Next d = new Next();
		assertEquals(d.nextday(1,11,1813),"2/11/1813");
	}
	@Test
	public void test18() {
		Next d = new Next();
		assertEquals(d.nextday(1,11,1912),"2/11/1912");
	}
	@Test
	public void test19() {
		Next d = new Next();
		assertEquals(d.nextday(1,11,2011),"2/11/2011");
	}
	@Test
	public void test20() {
		Next d = new Next();
		assertEquals(d.nextday(1,11,2012),"2/11/2012");
	}
	@Test
	public void test020() {
		Next d = new Next();
		assertEquals(d.nextday(1,11,2013),"Invalid Values");
		
	}
	@Test
	public void test021() {
		Next d = new Next();
		assertEquals(d.nextday(1,12,1811),"Invalid Values");
		
	}
	@Test
	public void test21() {
		Next d = new Next();
		assertEquals(d.nextday(1,12,1812),"2/12/1812");
		
	}
	@Test
	public void test22() {
		Next d = new Next();
		assertEquals(d.nextday(1,12,1813),"2/12/1813");
	}
	@Test
	public void test23() {
		Next d = new Next();
		assertEquals(d.nextday(1,12,1912),"2/12/1912");
	}
	@Test
	public void test24() {
		Next d = new Next();
		assertEquals(d.nextday(1,12,2011),"2/12/2011");
	}
	@Test
	public void test25() {
		Next d = new Next();
		assertEquals(d.nextday(1,12,2012),"2/12/2012");
	}
	@Test
	public void test025() {
		Next d = new Next();
		assertEquals(d.nextday(1,12,2013),"Invalid Values");
		
	}


}
